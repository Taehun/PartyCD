-- RosterManager.lua: 공대/파티 구성원 관리
local addonName, RCT = ...

-- 공대원 데이터 저장소
-- key = shortName (Ambiguate 처리됨), value = { unit, name, class, role, subgroup, online }
RCT.roster = {}
RCT.mySubgroup = 0

-- RT-2, RT-6: 이름 정규화 (크로스 렐름 대응)
local function NormalizeName(name)
    if not name then return nil end
    return Ambiguate(name, "short")
end

function RCT:InitRoster()
    RCT:RegisterEvent("GROUP_ROSTER_UPDATE", RCT.UpdateRoster)
    RCT:RegisterEvent("PLAYER_ENTERING_WORLD", function(self)
        -- FIX-1: ADDON_LOADED 시점에는 유닛 데이터 미준비, 지연 후 갱신
        C_Timer.After(1, function() RCT:UpdateRoster() end)
    end)
    -- FIX-1: 초기 UpdateRoster 제거 (ADDON_LOADED 시점에 유닛 데이터 없음)
    -- PLAYER_ENTERING_WORLD 또는 GROUP_ROSTER_UPDATE에서 처리
end

function RCT:UpdateRoster()
    wipe(RCT.roster)
    RCT.mySubgroup = 0

    if IsInRaid() then
        for i = 1, GetNumGroupMembers() do
            local unit = "raid" .. i
            RCT:AddUnitToRoster(unit, i)
            -- RT-2: UnitIsUnit으로 내 소그룹 확인 (크로스 렐름 안전)
            if UnitIsUnit(unit, "player") then
                local ok, _, _, subgroup = pcall(GetRaidRosterInfo, i)
                RCT.mySubgroup = (ok and subgroup) or 0
            end
        end
    elseif IsInGroup() then
        RCT:AddUnitToRoster("player", -1)
        for i = 1, GetNumGroupMembers() - 1 do
            local unit = "party" .. i
            RCT:AddUnitToRoster(unit, -1)
        end
        RCT.mySubgroup = 1
    end

    -- 로스터 결과 디버그
    local rosterCount = 0
    for _ in pairs(RCT.roster) do rosterCount = rosterCount + 1 end
    RCT:Debug("UpdateRoster: " .. rosterCount .. " members, inGroup=" .. tostring(IsInGroup()) .. " inRaid=" .. tostring(IsInRaid()))

    -- UI 갱신 트리거
    if RCT.OnRosterUpdate then
        RCT:OnRosterUpdate()
    elseif RCT.RefreshUI then
        -- FIX-5: OnRosterUpdate 콜백 미등록 시 (InitUI 이전) 직접 RefreshUI 호출
        RCT:Debug("UpdateRoster: OnRosterUpdate nil, fallback to RefreshUI")
        RCT:RefreshUI()
    end
end

function RCT:AddUnitToRoster(unit, raidIndex)
    if not UnitExists(unit) then return end

    local name = UnitName(unit)
    if not name then return end
    local shortName = NormalizeName(name)

    local _, classFile = UnitClass(unit)
    local role = UnitGroupRolesAssigned(unit)
    local subgroup = 0

    if raidIndex and raidIndex > 0 then
        local ok, _, _, sg = pcall(GetRaidRosterInfo, raidIndex)
        subgroup = (ok and sg) or 0
    elseif raidIndex and raidIndex == -1 then
        subgroup = 1
    end

    RCT.roster[shortName] = {
        unit = unit,
        name = shortName,
        class = classFile,
        role = role,
        subgroup = subgroup,
        online = UnitIsConnected(unit),
    }
end

-- 생존기 보유 멤버 목록 반환 (힐러 + 생존기 스펠 보유 클래스 모두 포함)
function RCT:GetHealers()
    local healers = {}
    for name, data in pairs(RCT.roster) do
        -- FIX-5: online 필터 제거 — 로딩/전환 중 UnitIsConnected()=false로 전원 필터링되는 문제 방지
        -- 오프라인 멤버도 바를 표시 (쿨다운 추적만 안 됨)
        if data.role == "HEALER" then
            healers[name] = data
        elseif RCT.SpellsByClass[data.class] then
            for _, spell in pairs(RCT.SpellsByClass[data.class]) do
                if spell.category == "SURVIVAL" then
                    healers[name] = data
                    break
                end
            end
        end
    end
    return healers
end

-- 같은 파티 소그룹의 딜러 목록 반환
function RCT:GetPartyInterrupters()
    local interrupters = {}
    for name, data in pairs(RCT.roster) do
        -- FIX-5: online 필터 제거 (GetHealers와 동일 이유)
        if data.subgroup == RCT.mySubgroup then
            if data.role ~= "HEALER" then
                interrupters[name] = data
            end
        end
    end
    return interrupters
end

-- 이름으로 공대원 정보 조회
function RCT:GetMemberInfo(name)
    return RCT.roster[NormalizeName(name)]
end

-- 유닛의 추적 대상 스킬 목록 반환 (category 지정 시 해당 카테고리만)
function RCT:GetTrackedSpellsForUnit(name, category)
    local member = RCT.roster[name]
    if not member then return {} end

    local classSpells = RCT.SpellsByClass[member.class]
    if not classSpells then return {} end

    local result = {}
    for spellID, data in pairs(classSpells) do
        if category then
            if data.category == category then
                result[spellID] = data
            end
        else
            if member.role == "HEALER" and data.category == "SURVIVAL" then
                result[spellID] = data
            elseif member.role ~= "HEALER" and data.category == "INTERRUPT" then
                result[spellID] = data
            end
        end
    end
    return result
end
